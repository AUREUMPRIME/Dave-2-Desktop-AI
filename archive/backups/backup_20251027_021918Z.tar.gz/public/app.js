﻿(() => {
  const q = s => document.querySelector(s);
  const canvas = q('#dos');
  const btn = q('#start');
  const fpsEl = q('#fps');

  btn.addEventListener('click', async () => {
    try{
      btn.disabled = true;
      // IMPORTANTE: Dos(...) devuelve un Promise en v8
      const player = await Dos(canvas, { pathPrefix: "/vendor/jsdos/emulators/" });
      const ci = await player.run("/dave2.jsdos");
      const ev = ci.events?.();
      if (ev?.onFps) ev.onFps(v => fpsEl.textContent = v);
      ev?.onFrame?.(()=>{}); // no-op, mantiene gancho
    }catch(e){
      document.body.innerHTML = `<pre style="color:#f55">API v8 error: ${e?.message||e}</pre>`;
    }
  });
})();
