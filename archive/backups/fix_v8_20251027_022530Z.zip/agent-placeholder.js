﻿(() => {
  // AEON Agent Placeholder v1 — usa js-dos CI: simulateKeyPress/sendKeyEvent
  // Teclas: ←(37) ↑(38) →(39) ↓(40) Ctrl(17) Espacio(32)
  const KEY = { LEFT:37, UP:38, RIGHT:39, DOWN:40, CTRL:17, SPACE:32 };
  const sleep = ms => new Promise(r=>setTimeout(r, ms));
  let running = false;

  function start(ci){
    if(running) return;
    running = true;
    console.info('agent running');
    const press = (...codes)=>ci.simulateKeyPress(...codes);
    (async () => {
      const cmds = [
        ()=>press(KEY.RIGHT),
        ()=>press(KEY.LEFT),
        ()=>press(KEY.UP),
        ()=>press(KEY.CTRL),
        ()=>press(KEY.SPACE),
        ()=>press(KEY.RIGHT, KEY.CTRL),
      ];
      while(running){
        try{
          const f = cmds[Math.floor(Math.random()*cmds.length)];
          f();
        }catch(e){ console.warn('agent error', e); }
        await sleep(300 + Math.random()*400);
      }
    })();
  }

  window.__agent_stop = ()=>{ running=false; console.info('agent stopped'); };

  window.addEventListener('dave2:ci-ready', ev => {
    try{ start(ev.detail.ci); }catch(e){ console.error(e); }
  });
})();
